# SHIPOVER Website

## Files
- `index.html` — Login + Register
- `home.html` — Home, slider, plans, payment section
- `style.css` — Complete responsive design
- `script.js` — Login/register, session, plans and UI logic

## GitHub
Upload all 4 files to the same repository folder (normally the root/main branch).

## Important
This version is a front-end demo. User accounts are stored in browser `localStorage`, and the payment screenshot is not uploaded to a server.

Before publishing:
1. Replace `YOUR-EASYPAISA-NUMBER` in `home.html` with the real payment number.
2. Replace `923000000000` in `script.js` with the official WhatsApp number.
3. For real user accounts and real payment verification, a backend/database is required.
