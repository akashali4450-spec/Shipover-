// SHIPOVER website JavaScript
const STORAGE_KEY = "shipover_users";
const SESSION_KEY = "shipover_current_user";

function getUsers(){
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch(e){ return []; }
}
function saveUsers(users){ localStorage.setItem(STORAGE_KEY, JSON.stringify(users)); }
function showMessage(el, text, error=false){
  if(!el) return;
  el.textContent = text;
  el.className = "message show" + (error ? " error" : "");
}
function normalizePhone(phone){ return phone.replace(/\s+/g,"").trim(); }

// Auth page
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");
const authMessage = document.getElementById("message");

if(loginForm && registerForm){
  loginTab.addEventListener("click",()=>{
    loginForm.classList.remove("hidden");
    registerForm.classList.add("hidden");
    loginTab.classList.add("active");
    registerTab.classList.remove("active");
    authMessage.className="message";
    authMessage.textContent="";
  });

  registerTab.addEventListener("click",()=>{
    registerForm.classList.remove("hidden");
    loginForm.classList.add("hidden");
    registerTab.classList.add("active");
    loginTab.classList.remove("active");
    authMessage.className="message";
    authMessage.textContent="";
  });

  registerForm.addEventListener("submit",(e)=>{
    e.preventDefault();
    const name=document.getElementById("registerName").value.trim();
    const phone=normalizePhone(document.getElementById("registerPhone").value);
    const password=document.getElementById("registerPassword").value;
    const confirm=document.getElementById("registerConfirm").value;
    if(password!==confirm){
      showMessage(authMessage,"Passwords do not match.",true); return;
    }
    const users=getUsers();
    if(users.some(u=>u.phone===phone)){
      showMessage(authMessage,"This phone number is already registered.",true); return;
    }
    users.push({name,phone,password});
    saveUsers(users);
    showMessage(authMessage,"Account created successfully. Please login.");
    registerForm.reset();
    setTimeout(()=>loginTab.click(),700);
  });

  loginForm.addEventListener("submit",(e)=>{
    e.preventDefault();
    const phone=normalizePhone(document.getElementById("loginPhone").value);
    const password=document.getElementById("loginPassword").value;
    const user=getUsers().find(u=>u.phone===phone && u.password===password);
    if(!user){
      showMessage(authMessage,"Incorrect phone number or password.",true); return;
    }
    localStorage.setItem(SESSION_KEY,JSON.stringify({name:user.name,phone:user.phone}));
    window.location.href="home.html";
  });
}

// Home page
const logoutBtn=document.getElementById("logoutBtn");
if(logoutBtn){
  const current=JSON.parse(localStorage.getItem(SESSION_KEY)||"null");
  if(!current){ window.location.href="index.html"; }
  else{
    const welcome=document.getElementById("welcomeUser");
    if(welcome) welcome.textContent="Hi, "+current.name;
  }

  logoutBtn.addEventListener("click",()=>{
    localStorage.removeItem(SESSION_KEY);
    window.location.href="index.html";
  });

  const slides=[...document.querySelectorAll(".slide")];
  let slideIndex=0;
  if(slides.length){
    setInterval(()=>{
      slides[slideIndex].classList.remove("active");
      slideIndex=(slideIndex+1)%slides.length;
      slides[slideIndex].classList.add("active");
    },3000);
  }

  let selectedAmount=null;
  document.querySelectorAll(".plan-card").forEach(card=>{
    card.addEventListener("click",()=>{
      selectedAmount=card.dataset.plan;
      const selected=document.getElementById("selectedPlan");
      if(selected) selected.textContent="Rs. "+Number(selectedAmount).toLocaleString("en-PK");
      document.getElementById("payment").scrollIntoView({behavior:"smooth"});
    });
  });

  const fileInput=document.getElementById("paymentScreenshot");
  const fileName=document.getElementById("fileName");
  if(fileInput){
    fileInput.addEventListener("change",()=>{
      fileName.textContent=fileInput.files.length ? fileInput.files[0].name : "No screenshot selected.";
    });
  }

  const submitPayment=document.getElementById("submitPayment");
  const paymentMessage=document.getElementById("paymentMessage");
  if(submitPayment){
    submitPayment.addEventListener("click",()=>{
      if(!selectedAmount){
        showMessage(paymentMessage,"Please select a plan first.",true); return;
      }
      if(!fileInput.files.length){
        showMessage(paymentMessage,"Please select your payment screenshot.",true); return;
      }
      showMessage(paymentMessage,"Payment screenshot selected. This demo does not send files to a server.");
    });
  }

  const whatsappBtn=document.getElementById("whatsappBtn");
  if(whatsappBtn){
    // Replace the number below with your official WhatsApp number.
    const whatsappNumber="923000000000";
    whatsappBtn.href="https://wa.me/"+whatsappNumber;
    whatsappBtn.target="_blank";
    whatsappBtn.rel="noopener";
  }

  const year=document.getElementById("year");
  if(year) year.textContent=new Date().getFullYear();
}
